from flask import Flask, render_template, request, redirect, url_for, flash, g, jsonify, send_from_directory, abort
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
from datetime import datetime, timedelta
import os
import uuid
import re
import secrets
from email_validator import validate_email, EmailNotValidError
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Configuration
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', os.urandom(24))
DATABASE = os.environ.get('DATABASE_URL', 'sndr.db')
UPLOAD_FOLDER = os.path.join(app.static_folder, 'uploads/profile_images')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5MB max file size

# Create upload directory if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'info'

class User(UserMixin):
    def __init__(self, id, username, email, password_hash, profile_image, created_at, last_login=None, is_active=True):
        self.id = id
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.profile_image = profile_image
        self.created_at = created_at
        self.last_login = last_login
        self._is_active = is_active

    @property
    def is_active(self):
        return self._is_active

    @is_active.setter
    def is_active(self, value):
        self._is_active = value

@login_manager.user_loader
def load_user(user_id):
    user = query_db('SELECT * FROM users WHERE id = ?', [user_id], one=True)
    if user:
        # Set a default profile image if None or empty string
        profile_image = user['profile_image'] if user['profile_image'] else 'default.jpg'
        
        return User(
            id=user['id'],
            username=user['username'],
            email=user['email'],
            password_hash=user['password_hash'],
            profile_image=profile_image,
            created_at=user['created_at'],
            last_login=user['last_login'],
            is_active=user['is_active']
        )
    return None

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.executescript(f.read())
        db.commit()

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

def insert_db(query, args=()):
    db = get_db()
    db.execute(query, args)
    db.commit()
    return db.execute('SELECT last_insert_rowid()').fetchone()[0]

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_profile_image(file):
    if file and allowed_file(file.filename):
        # Generate a unique filename
        filename = secure_filename(file.filename)
        name, ext = os.path.splitext(filename)
        unique_filename = f"{uuid.uuid4().hex}{ext}"
        
        # Save the file
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(file_path)
        return unique_filename
    return None

def validate_username(username):
    if not username or len(username) < 3:
        return False, "Username must be at least 3 characters long"
    if not re.match("^[a-zA-Z0-9_]+$", username):
        return False, "Username can only contain letters, numbers, and underscores"
    return True, ""

def validate_password(password):
    if not password or len(password) < 8:
        return False, "Password must be at least 8 characters long"
    if not re.search(r"[A-Z]", password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search(r"[a-z]", password):
        return False, "Password must contain at least one lowercase letter"
    if not re.search(r"\d", password):
        return False, "Password must contain at least one number"
    return True, ""

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        print(f"[DEBUG] User already logged in: {current_user.username}")
        return redirect(url_for('inbox', username=current_user.username))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = request.form.get('remember', False)
        
        print(f"[DEBUG] Login attempt for username: {username}")
        
        # Check if username exists
        user = query_db('SELECT * FROM users WHERE username = ?', [username], one=True)
        if not user:
            print(f"[DEBUG] Username not found: {username}")
            flash('Username not found. Please check your username or register for an account.', 'error')
            return render_template('login.html', username=username)
        
        # Check password
        if not check_password_hash(user['password_hash'], password):
            print(f"[DEBUG] Invalid password for username: {username}")
            flash('Invalid password. Please try again or reset your password.', 'error')
            return render_template('login.html', username=username)
        
        if not user['is_active']:
            print(f"[DEBUG] Inactive account attempt: {username}")
            flash('This account is no longer active', 'error')
            return redirect(url_for('login'))
            
        user_obj = User(
            id=user['id'],
            username=user['username'],
            email=user['email'],
            password_hash=user['password_hash'],
            profile_image=user['profile_image'] if user['profile_image'] else 'default.jpg',
            created_at=user['created_at'],
            last_login=user['last_login'],
            is_active=user['is_active']
        )
        login_user(user_obj, remember=remember)
        print(f"[DEBUG] User logged in successfully: {username}")
        
        # Update last login
        db = get_db()
        db.execute('UPDATE users SET last_login = ? WHERE id = ?',
                  [datetime.now().strftime('%Y-%m-%d %H:%M:%S'), user['id']])
        db.commit()
        
        print(f"[DEBUG] Redirecting to inbox for user: {user_obj.username}")
        return redirect(url_for('inbox', username=user_obj.username))
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out successfully', 'success')
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate username
        is_valid, message = validate_username(username)
        if not is_valid:
            flash(message, 'error')
            return redirect(url_for('register'))
        
        # Validate email
        try:
            validate_email(email)
        except EmailNotValidError as e:
            flash(str(e), 'error')
            return redirect(url_for('register'))
        
        # Validate password
        is_valid, message = validate_password(password)
        if not is_valid:
            flash(message, 'error')
            return redirect(url_for('register'))
        
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return redirect(url_for('register'))
        
        # Check if username or email already exists
        existing_user = query_db('SELECT * FROM users WHERE username = ? OR email = ?',
                               [username, email], one=True)
        if existing_user:
            if existing_user['username'] == username:
                flash('Username already exists', 'error')
            else:
                flash('Email already registered', 'error')
            return redirect(url_for('register'))
        
        # Create new user
        password_hash = generate_password_hash(password)
        created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        user_id = insert_db('''
            INSERT INTO users (username, email, password_hash, created_at)
            VALUES (?, ?, ?, ?)
        ''', [username, email, password_hash, created_at])
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/u/<username>')
def profile(username):
    user = query_db('SELECT * FROM users WHERE username = ?', [username], one=True)
    if user is None:
        flash('User not found', 'error')
        return redirect(url_for('index'))
    
    # Set a default profile image if None or empty string
    if not user['profile_image']:
        user = dict(user)  # Convert to dict to make it mutable
        user['profile_image'] = 'default.jpg'
        
    return render_template('profile.html', user=user)

@app.route('/update_profile', methods=['POST'])
@login_required
def update_profile():
    try:
        # Handle profile image upload
        if 'profile_image' in request.files:
            file = request.files['profile_image']
            if file.filename != '':
                filename = save_profile_image(file)
                if filename:
                    db = get_db()
                    db.execute('UPDATE users SET profile_image = ? WHERE id = ?', 
                              [filename, current_user.id])
                    db.commit()
                    flash('Profile image updated!', 'success')
                else:
                    flash('Invalid file type. Please upload a valid image (JPG, PNG, GIF).', 'error')
            
        return redirect(url_for('profile', username=current_user.username))
    except Exception as e:
        print(f"Error updating profile: {e}")
        flash('Error updating profile. Please try again.', 'error')
        return redirect(url_for('profile', username=current_user.username))

@app.route('/reply_to_instagram/<message_id>', methods=['GET'])
@login_required
def reply_to_instagram(message_id):
    try:
        # Get the message content
        message = query_db('SELECT * FROM messages WHERE id = ? AND user_id = ?',
                         [message_id, current_user.id], one=True)
        if not message:
            flash('Message not found', 'error')
            return redirect(url_for('inbox', username=current_user.username))
        
        # Prepare message text for Instagram - truncate if too long
        message_text = message['content']
        if len(message_text) > 100:
            message_text = message_text[:97] + '...'
        
        # Create Instagram story deep link
        # Note: This uses a URL scheme that will open Instagram stories
        # Instagram URL scheme: instagram://story-camera
        
        instagram_url = 'instagram://story-camera'
        
        # Mark message as read if not already
        if not message['read']:
            db = get_db()
            db.execute('UPDATE messages SET read = 1 WHERE id = ?', [message_id])
            db.commit()
        
        # Note: We can't directly share text to Instagram stories via URL
        # The user will need to manually paste the message text
        flash('Instagram will open. Copy and paste your message there to share it!', 'info')
        
        # We'll return a page that auto-redirects to Instagram and displays the message to copy
        return render_template('redirect_to_instagram.html', 
                              message=message_text,
                              instagram_url=instagram_url)
    
    except Exception as e:
        print(f"Error replying to Instagram: {e}")
        flash('Error opening Instagram. Please try manually.', 'error')
        return redirect(url_for('inbox', username=current_user.username))

@app.route('/send', methods=['POST'])
def send_message():
    try:
        username = request.form.get('username')
        message = request.form.get('message')
        
        if not username or not message:
            flash('Username and message are required', 'error')
            return redirect(url_for('profile', username=username))
        
        if len(message.strip()) == 0:
            flash('Message cannot be empty', 'error')
            return redirect(url_for('profile', username=username))
        
        user = query_db('SELECT * FROM users WHERE username = ?', [username], one=True)
        if not user:
            flash('User not found', 'error')
            return redirect(url_for('index'))
        
        if not user['is_active']:
            flash('This user account is no longer active', 'error')
            return redirect(url_for('index'))
        
        insert_db('''
            INSERT INTO messages (content, user_id, created_at)
            VALUES (?, ?, ?)
        ''', [message.strip(), user['id'], datetime.now().strftime('%Y-%m-%d %H:%M:%S')])
        
        flash('Message sent successfully!', 'success')
    except Exception as e:
        print(f"Error sending message: {e}")
        flash('Error sending message. Please try again.', 'error')
    
    return redirect(url_for('profile', username=username))

@app.route('/inbox/<username>')
@login_required
def inbox(username):
    try:
        print(f"[DEBUG] Accessing inbox for username in URL: {username}")
        print(f"[DEBUG] Current logged-in user: {current_user.username}")
        
        # First check if the user exists
        user = query_db('SELECT * FROM users WHERE username = ?', [username], one=True)
        print(f"[DEBUG] User from DB: {user}")
        if not user:
            print(f"[DEBUG] User not found: {username}")
            flash('User not found', 'error')
            return redirect(url_for('index'))
        print(f"[DEBUG] User is_active: {user['is_active']}")
        
        # Then check if the current user is authorized to view this inbox
        if current_user.username != username:
            print(f"[DEBUG] Unauthorized access attempt: {current_user.username} trying to access {username}'s inbox")
            flash('You can only view your own inbox', 'error')
            return redirect(url_for('index'))
        
        # Get messages with proper error handling
        try:
            print(f"[DEBUG] Fetching messages for user_id: {current_user.id}")
            messages = query_db('''
                SELECT id, content, created_at, 
                       CASE WHEN read = 1 THEN 1 ELSE 0 END as is_read
                FROM messages 
                WHERE user_id = ? 
                ORDER BY created_at DESC
            ''', [current_user.id])
            
            if messages is None:
                print("[DEBUG] No messages found")
                messages = []
            else:
                print(f"[DEBUG] Found {len(messages)} messages")
                
        except sqlite3.Error as e:
            print(f"[DEBUG] Database error in inbox: {str(e)}")
            flash('Error loading messages. Please try again.', 'error')
            return redirect(url_for('index'))
        
        print("[DEBUG] Successfully loaded inbox")
        return render_template('inbox.html', messages=messages, user=user)
        
    except Exception as e:
        print(f"[DEBUG] Unexpected error in inbox route: {str(e)}")
        import traceback
        print(traceback.format_exc())
        flash('Error loading inbox. Please try again.', 'error')
        return redirect(url_for('index'))

@app.route('/uploads/profile_images/<filename>')
def uploaded_file(filename):
    # Ensure the file exists or return a default image
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if not os.path.exists(file_path):
        return send_from_directory(app.config['UPLOAD_FOLDER'], 'default.jpg')
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/mark_as_read/<int:message_id>', methods=['POST'])
@login_required
def mark_as_read(message_id):
    try:
        message = query_db('SELECT * FROM messages WHERE id = ? AND user_id = ?',
                         [message_id, current_user.id], one=True)
        if not message:
            return jsonify({'success': False, 'error': 'Message not found'}), 404
        
        db = get_db()
        db.execute('UPDATE messages SET read = 1 WHERE id = ?', [message_id])
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        print(f"Error marking message as read: {e}")
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

@app.route('/delete_message/<int:message_id>', methods=['POST'])
@login_required
def delete_message(message_id):
    try:
        # Verify the message belongs to the current user
        message = query_db('SELECT * FROM messages WHERE id = ? AND user_id = ?',
                         [message_id, current_user.id], one=True)
        if not message:
            return jsonify({'success': False, 'error': 'Message not found'}), 404
        
        db = get_db()
        db.execute('DELETE FROM messages WHERE id = ?', [message_id])
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        print(f"Error deleting message: {e}")
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

@app.route('/profile')
@login_required
def my_profile():
    return redirect(url_for('profile', username=current_user.username))

# Password reset functionality
@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        
        # Validate email format
        try:
            validate_email(email)
        except EmailNotValidError:
            flash('Please enter a valid email address', 'error')
            return render_template('forgot_password.html')
        
        # Check if email exists
        user = query_db('SELECT * FROM users WHERE email = ?', [email], one=True)
        if not user:
            # Don't reveal if email exists or not (security best practice)
            flash('If this email is registered, you will receive a password reset link shortly.', 'info')
            return redirect(url_for('login'))
        
        # Generate token
        token = secrets.token_urlsafe(32)
        token_expiry = (datetime.now() + timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S')
        
        # Store token in database
        try:
            # First, expire any existing tokens
            db = get_db()
            db.execute('DELETE FROM password_reset_tokens WHERE user_id = ?', [user['id']])
            
            # Then insert new token
            db.execute('''
                INSERT INTO password_reset_tokens (user_id, token, expiry_date)
                VALUES (?, ?, ?)
            ''', [user['id'], token, token_expiry])
            db.commit()
            
            # Generate reset link
            reset_link = url_for('reset_password', token=token, _external=True)
            
            # In a real app, you would send an email here
            # For demo, we'll just flash the link
            print(f"[DEBUG] Reset link for {email}: {reset_link}")
            flash(f'Reset link (for demo purposes): <a href="{reset_link}">Reset Password</a>', 'info')
            
            flash('If this email is registered, you will receive a password reset link shortly.', 'info')
            return redirect(url_for('login'))
            
        except Exception as e:
            print(f"[DEBUG] Error generating reset token: {e}")
            flash('An error occurred. Please try again later.', 'error')
    
    return render_template('forgot_password.html')

@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    # Check if token exists and is valid
    token_data = query_db('''
        SELECT user_id, expiry_date FROM password_reset_tokens 
        WHERE token = ? AND expiry_date > ?
    ''', [token, datetime.now().strftime('%Y-%m-%d %H:%M:%S')], one=True)
    
    if not token_data:
        flash('Invalid or expired password reset link', 'error')
        return redirect(url_for('forgot_password'))
    
    user = query_db('SELECT * FROM users WHERE id = ?', [token_data['user_id']], one=True)
    if not user:
        flash('User not found', 'error')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate password
        is_valid, message = validate_password(password)
        if not is_valid:
            flash(message, 'error')
            return render_template('reset_password.html', token=token)
        
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('reset_password.html', token=token)
        
        # Update password
        try:
            db = get_db()
            db.execute('UPDATE users SET password_hash = ? WHERE id = ?', 
                       [generate_password_hash(password), user['id']])
            
            # Delete used token
            db.execute('DELETE FROM password_reset_tokens WHERE token = ?', [token])
            db.commit()
            
            flash('Your password has been reset! You can now log in with your new password.', 'success')
            return redirect(url_for('login'))
            
        except Exception as e:
            print(f"[DEBUG] Error resetting password: {e}")
            flash('An error occurred. Please try again.', 'error')
    
    return render_template('reset_password.html', token=token)

if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
    app.run(debug=os.environ.get('FLASK_DEBUG', 'False').lower() == 'true', 
            host=os.environ.get('FLASK_HOST', '0.0.0.0'),
            port=int(os.environ.get('FLASK_PORT', 5000)))